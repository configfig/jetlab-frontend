const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const Joi = require('joi');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(helmet());
app.use(cors({
  origin: ['http://localhost:3000', 'https://jetlabco.com', 'https://www.jetlabco.com'],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const emailLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 requests per windowMs
  message: {
    error: 'Too many email requests from this IP, please try again later.'
  }
});

// SMTP Configuration
const transporter = nodemailer.createTransporter({
  host: 'smtp.jetlabco.com',
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: 'info@jetlabco.com',
    pass: 'Vv1G2zR9u9'
  },
  tls: {
    rejectUnauthorized: false // Allow self-signed certificates
  }
});

// Verify SMTP connection
transporter.verify((error, success) => {
  if (error) {
    console.log('SMTP connection error:', error);
  } else {
    console.log('✅ SMTP server is ready to take our messages');
  }
});

// Validation schemas
const contactSchema = Joi.object({
  name: Joi.string().min(2).max(100).required(),
  email: Joi.string().email().required(),
  phone: Joi.string().min(10).max(20).required(),
  service: Joi.string().min(2).max(100).required(),
  message: Joi.string().max(2000).optional()
});

const quizSchema = Joi.object({
  name: Joi.string().min(2).max(100).required(),
  email: Joi.string().email().required(),
  phone: Joi.string().min(10).max(20).required(),
  company: Joi.string().max(100).optional(),
  service: Joi.string().min(2).max(100).required(),
  budget: Joi.string().required(),
  timeline: Joi.string().required(),
  goals: Joi.array().items(Joi.string()).required(),
  description: Joi.string().max(2000).required()
});

const newsletterSchema = Joi.object({
  email: Joi.string().email().required()
});

// Utility function to format phone number
const formatPhoneNumber = (phone) => {
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 11 && cleaned.startsWith('1')) {
    return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
  } else if (cleaned.length === 10) {
    return `+1 (${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  }
  return phone;
};

// Routes

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'JetLab Email Server is running',
    timestamp: new Date().toISOString()
  });
});

// Contact form endpoint
app.post('/api/contact', emailLimiter, async (req, res) => {
  try {
    // Validate input
    const { error, value } = contactSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: error.details[0].message
      });
    }

    const { name, email, phone, service, message } = value;
    const formattedPhone = formatPhoneNumber(phone);

    // Email content
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #000; color: white; padding: 20px; border-radius: 8px 8px 0 0; }
          .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 8px 8px; }
          .field { margin-bottom: 15px; }
          .label { font-weight: bold; color: #555; }
          .value { margin-top: 5px; }
          .footer { text-align: center; margin-top: 20px; padding: 20px; color: #888; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h2>📧 New Contact Form Submission</h2>
            <p>From: ${name}</p>
          </div>
          <div class="content">
            <div class="field">
              <div class="label">👤 Name:</div>
              <div class="value">${name}</div>
            </div>
            <div class="field">
              <div class="label">📧 Email:</div>
              <div class="value"><a href="mailto:${email}">${email}</a></div>
            </div>
            <div class="field">
              <div class="label">📞 Phone:</div>
              <div class="value"><a href="tel:${phone}">${formattedPhone}</a></div>
            </div>
            <div class="field">
              <div class="label">🛠️ Service:</div>
              <div class="value">${service}</div>
            </div>
            ${message ? `
            <div class="field">
              <div class="label">💬 Message:</div>
              <div class="value">${message.replace(/\n/g, '<br>')}</div>
            </div>
            ` : ''}
          </div>
          <div class="footer">
            <p>Sent from JetLab Contact Form | ${new Date().toLocaleString()}</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: `"JetLab Contact Form" <info@jetlabco.com>`,
      to: 'info@jetlabco.com',
      replyTo: email,
      subject: `🚀 New ${service} Inquiry from ${name}`,
      html: htmlContent,
      text: `
New Contact Form Submission

Name: ${name}
Email: ${email}
Phone: ${formattedPhone}
Service: ${service}
${message ? `Message: ${message}` : ''}

Sent: ${new Date().toLocaleString()}
      `.trim()
    };

    // Send email
    const info = await transporter.sendMail(mailOptions);
    
    console.log('✅ Contact email sent:', info.messageId);
    
    res.json({
      success: true,
      message: 'Contact form submitted successfully',
      messageId: info.messageId
    });

  } catch (error) {
    console.error('❌ Contact form error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to send contact form',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Quiz form endpoint
app.post('/api/quiz', emailLimiter, async (req, res) => {
  try {
    // Validate input
    const { error, value } = quizSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: error.details[0].message
      });
    }

    const { name, email, phone, company, service, budget, timeline, goals, description } = value;
    const formattedPhone = formatPhoneNumber(phone);

    // Email content
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #000 0%, #333 100%); color: white; padding: 25px; border-radius: 8px 8px 0 0; }
          .content { background: #f9f9f9; padding: 25px; border-radius: 0 0 8px 8px; }
          .section { margin-bottom: 25px; padding: 15px; background: white; border-radius: 6px; border-left: 4px solid #000; }
          .field { margin-bottom: 12px; }
          .label { font-weight: bold; color: #555; text-transform: uppercase; font-size: 12px; }
          .value { margin-top: 5px; font-size: 16px; }
          .goals { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; }
          .goal-tag { background: #000; color: white; padding: 4px 12px; border-radius: 20px; font-size: 12px; }
          .footer { text-align: center; margin-top: 20px; padding: 20px; color: #888; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h2>🎯 New ${service} Consultation Request</h2>
            <p>Detailed project inquiry from ${name}</p>
          </div>
          <div class="content">
            <div class="section">
              <h3>👤 Client Information</h3>
              <div class="field">
                <div class="label">Name</div>
                <div class="value">${name}</div>
              </div>
              <div class="field">
                <div class="label">Email</div>
                <div class="value"><a href="mailto:${email}">${email}</a></div>
              </div>
              <div class="field">
                <div class="label">Phone</div>
                <div class="value"><a href="tel:${phone}">${formattedPhone}</a></div>
              </div>
              ${company ? `
              <div class="field">
                <div class="label">Company</div>
                <div class="value">${company}</div>
              </div>
              ` : ''}
            </div>

            <div class="section">
              <h3>💼 Project Details</h3>
              <div class="field">
                <div class="label">Service</div>
                <div class="value">${service}</div>
              </div>
              <div class="field">
                <div class="label">Budget</div>
                <div class="value">${budget}</div>
              </div>
              <div class="field">
                <div class="label">Timeline</div>
                <div class="value">${timeline}</div>
              </div>
            </div>

            <div class="section">
              <h3>🎯 Project Goals</h3>
              <div class="goals">
                ${goals.map(goal => `<span class="goal-tag">${goal}</span>`).join('')}
              </div>
            </div>

            <div class="section">
              <h3>📝 Project Description</h3>
              <div class="value">${description.replace(/\n/g, '<br>')}</div>
            </div>
          </div>
          <div class="footer">
            <p>Sent from JetLab Consultation Form | ${new Date().toLocaleString()}</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: `"JetLab Consultation" <info@jetlabco.com>`,
      to: 'info@jetlabco.com',
      replyTo: email,
      subject: `🎯 ${service} Consultation - ${name} (${budget})`,
      html: htmlContent,
      text: `
New Consultation Request

Client Information:
- Name: ${name}
- Email: ${email}
- Phone: ${formattedPhone}
${company ? `- Company: ${company}` : ''}

Project Details:
- Service: ${service}
- Budget: ${budget}
- Timeline: ${timeline}
- Goals: ${goals.join(', ')}

Project Description:
${description}

Sent: ${new Date().toLocaleString()}
      `.trim()
    };

    // Send email
    const info = await transporter.sendMail(mailOptions);
    
    console.log('✅ Quiz email sent:', info.messageId);
    
    res.json({
      success: true,
      message: 'Consultation request submitted successfully',
      messageId: info.messageId
    });

  } catch (error) {
    console.error('❌ Quiz form error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to send consultation request',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Newsletter subscription endpoint
app.post('/api/newsletter', emailLimiter, async (req, res) => {
  try {
    // Validate input
    const { error, value } = newsletterSchema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: error.details[0].message
      });
    }

    const { email } = value;

    // Email content
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #000; color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center; }
          .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 8px 8px; }
          .footer { text-align: center; margin-top: 20px; padding: 20px; color: #888; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h2>📧 New Newsletter Subscription</h2>
          </div>
          <div class="content">
            <p><strong>Email:</strong> <a href="mailto:${email}">${email}</a></p>
            <p><strong>Subscribed:</strong> ${new Date().toLocaleString()}</p>
          </div>
          <div class="footer">
            <p>Sent from JetLab Newsletter Subscription</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: `"JetLab Newsletter" <info@jetlabco.com>`,
      to: 'info@jetlabco.com',
      subject: `📧 New Newsletter Subscription`,
      html: htmlContent,
      text: `
New Newsletter Subscription

Email: ${email}
Subscribed: ${new Date().toLocaleString()}
      `.trim()
    };

    // Send email
    const info = await transporter.sendMail(mailOptions);
    
    console.log('✅ Newsletter email sent:', info.messageId);
    
    res.json({
      success: true,
      message: 'Newsletter subscription successful',
      messageId: info.messageId
    });

  } catch (error) {
    console.error('❌ Newsletter error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to subscribe to newsletter',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('❌ Server error:', err);
  res.status(500).json({
    success: false,
    error: 'Internal server error',
    details: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint not found'
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 JetLab Email Server running on port ${PORT}`);
  console.log(`📧 SMTP configured for info@jetlabco.com`);
  console.log(`🌐 CORS enabled for frontend origins`);
});

module.exports = app;